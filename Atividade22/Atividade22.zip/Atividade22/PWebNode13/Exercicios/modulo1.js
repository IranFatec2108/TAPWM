var texto = ('Observe que essa mensagem vem do Modulo');
module.exports=texto;