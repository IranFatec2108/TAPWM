module.exports = function(app) {
    app.get('/informacao/professores', async function(req, res) {
        const sql = require('mssql');

        const sqlConfig = {
            user: 'BD2412013',
            password: 'MasterChief21#',
            database: 'BD', // Na FATEC, utilizar o database BD ou LP8
            server: 'Apolo', // Caso o nome tenha uma instância, colocar duas barras, ex: ‘DESKTOP\\SQLSERVER. Na FATEC, utilizar o ip: 192.168.1.6 no nome do servidor
            options: {
                encrypt: false,
                trustServerCertificate: true
            }
        };

        try {
            const pool = await sql.connect(sqlConfig);
            const results = await pool.request().query('SELECT * from PROFESSORES');
            res.send(results.recordsets); // Enviando os resultados como resposta
        } catch (err) {
            console.log(err);
            res.status(500).send('Erro ao buscar dados'); // Enviando uma resposta de erro
        }
    });
};
